package com.xfw.shuttershadow.core.chunk_loading;

/** 相机按从中心向外的顺序查找渲染区域。 */
public class BlockTraverse {
    public interface BiIntFunc<T> {
        T eval(int x, int z);
    }

    public static <T> T searchOnPlane(
        int centerX, int centerZ, int range,
        BiIntFunc<T> func
    ) {
        T centerResult = func.eval(centerX, centerZ);
        if (centerResult != null) {
            return centerResult;
        }
        
        for (int layer = 1; layer < range; layer++) {
            for (int w = 0; w < layer * 2; w++) {
                T obj = func.eval(layer + centerX, w + 1 - layer + centerZ);
                if (obj != null) {
                    return obj;
                }
            }
            
            for (int w = 0; w < layer * 2; w++) {
                T obj = func.eval(-w + layer - 1 + centerX, layer + centerZ);
                if (obj != null) {
                    return obj;
                }
            }
            
            for (int w = 0; w < layer * 2; w++) {
                T obj = func.eval(-layer + centerX, -w + layer - 1 + centerZ);
                if (obj != null) {
                    return obj;
                }
            }
            
            for (int w = 0; w < layer * 2; w++) {
                T obj = func.eval(w + 1 - layer + centerX, -layer + centerZ);
                if (obj != null) {
                    return obj;
                }
            }
        }
        
        return null;
    }
    
}
